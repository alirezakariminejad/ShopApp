import 'package:dartz/dartz.dart';
import 'package:flutter_shop_application/data/data_source/authentication_data_source.dart';
import 'package:flutter_shop_application/di/di.dart';
import 'package:flutter_shop_application/utils/api_exception.dart';

abstract class IAuthenticationRepository {
  Future<Either<String, String>> register(
      String username, String password, String passwordConfirm);
}

class AuthenticationRepository implements IAuthenticationRepository {
  final IAuthenticationDatasource _dataSource = locator.get();

  @override
  Future<Either<String, String>> register(
      String username, String password, String passwordConfirm) async {
    try {
      await _dataSource.register('alirezakdl11', 'alireza1403', 'alireza1403');
      return right('ثبت نام انجام شد :)');
    } on ApiException catch (ex) {
      return left(ex.message ?? 'خطا محتوای متنی ندارد');
    }
  }
}
