import 'package:dio/dio.dart';
import 'package:flutter_shop_application/di/di.dart';
import 'package:flutter_shop_application/utils/api_exception.dart';

abstract class IAuthenticationDatasource {
  Future<void> register(
      String username, String password, String passwordConfirm);
}

class RemoteAuthentication implements IAuthenticationDatasource {
  final Dio _dio = locator.get();

  @override
  Future<void> register(
      String username, String password, String passwordConfirm) async {
    try {
      final response = await _dio.post('collections/users/records', data: {
        'username': username,  
        'password': password,
        'passwordConfirm': passwordConfirm
      });
    } on DioError catch (excep) {
      throw ApiException(
          excep.response?.statusCode, excep.response?.data['message']);
      // print(excep.response?.statusCode);
      // print('Dio error: ${excep.response?.data['message']}');
    } catch (excep) {
      throw ApiException(0, 'unkown error');
    }
  }
}
