import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter_shop_application/data/data_source/authentication_data_source.dart';
import 'package:flutter_shop_application/data/repository/authentication_repository.dart';
import 'package:get_it/get_it.dart';

var locator = GetIt.instance;
Future<void> getItInit() async {
  locator.registerSingleton<Dio>(
      Dio(BaseOptions(baseUrl: 'https://startflutter.ir/api/')));

  //datasources
  locator
      .registerFactory<IAuthenticationDatasource>(() => RemoteAuthentication());

  //repositories
  locator.registerFactory<IAuthenticationRepository>(
      () => AuthenticationRepository());
 }
