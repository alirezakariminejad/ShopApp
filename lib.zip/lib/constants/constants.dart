import 'package:flutter/material.dart';

const Color shopBlue = Color(0xff3B5EDF);
const Color shopWhite = Color(0xffEEEEEE);
const Color shopGray = Color(0xff858585);
const Color shopGreen = Color(0xff1DB68B);
const Color shopRed = Color(0xffD02026);
const Color scaffoldGray = Color(0xffEEEEEE);
